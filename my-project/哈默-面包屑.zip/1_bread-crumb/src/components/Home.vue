<template>
  <div id="home">
    <h1>首页</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {

};
</script>

<style></style>
