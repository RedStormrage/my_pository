const state = {
  isFirstView: true,
  isLoading: false,
  users: null,
  error: "",
};

export default state;
