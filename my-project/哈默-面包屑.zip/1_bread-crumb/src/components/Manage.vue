<template>
  <div id="manage">
    <h1>活动管理</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  
};
</script>

<style></style>
