<template>
  <div>
    Father
    <Child />
  </div>
</template>

<script>
import Child from "./Child";
export default {
  components: {
    Child,
  },
};
</script>

<style scoped></style>
