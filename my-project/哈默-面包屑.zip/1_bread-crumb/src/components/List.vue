<template>
  <div id="list">
    <h1>活动列表</h1>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
