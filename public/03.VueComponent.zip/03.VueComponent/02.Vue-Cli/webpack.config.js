const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
// https://vue-loader.vuejs.org/zh/guide/#%E6%89%8B%E5%8A%A8%E8%AE%BE%E7%BD%AE
const VueLoaderPlugin = require("vue-loader/lib/plugin");
const CopyPlugin = require("copy-webpack-plugin");

module.exports = {
  entry: "./src/main.js",
  output: {
    path: undefined,
    filename: "js/[name].js",
  },
  module: {
    rules: [
      // loader配置
      // npm i vue-style-loader css-loader -D
      // 它会应用到普通的 `.css` 文件
      // 以及 `.vue` 文件中的 `<style>` 块
      {
        test: /\.css$/,
        include: [ // 包含 src 目录下面的文件：只处理src下面的文件
          path.resolve(__dirname, 'src')
        ],
        use: ["vue-style-loader", "css-loader"],
      },
      {
        // npm i url-loader file-loader -D
        test: /\.(jpe?g|png|gif|webp)$/,
        include: [ // 包含 src 目录下面的文件：只处理src下面的文件
          path.resolve(__dirname, 'src')
        ],
        loader: "url-loader",
        options: {
          limit: 8 * 1024,
          name: "static/media/[name].[hash:10].[ext]",
        },
      },
      {
        // npm i html-loader -D
        test: /\.(html)$/,
        loader: "html-loader",
        options: {
          attributes: {
            list: [
              {
                // Attribute name
                attribute: "src",
                // Type of processing, can be `src` or `scrset`
                type: "src",
                // Allow to filter some attributes (optional)
                filter: (tag, attribute, attributes, resourcePath) => {
                  // 过滤除img标签以外的元素
                  // 只处理img图片
                  return tag.toLowerCase() === "img";
                },
              },
            ],
          },
        },
      },
      {
        test: /\.vue$/,
        include: [ // 包含 src 目录下面的文件：只处理src下面的文件
          path.resolve(__dirname, 'src')
        ],
        loader: "vue-loader",
      },
      // 它会应用到普通的 `.js` 文件
      // 以及 `.vue` 文件中的 `<script>` 块
      // npm i @babel/core babel-loader -D
      {
        test: /\.js$/,
        exclude: /node_modules/, // 排除 node_modules 不编译
        loader: "babel-loader",
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, "public/index.html"),
    }),
    new VueLoaderPlugin(),
    // 克隆插件
    new CopyPlugin({
      patterns: [
        {
          from: path.resolve(__dirname, "public"),
          to: path.resolve(__dirname, "dist"),
          globOptions: {
            // 忽略 index.html 不复制
            // 原因：因为 index.html 已经被 HtmlWebpackPlugin 处理过了
            ignore: ["index.html"],
          },
        },
      ],
    }),
  ],
  mode: "development",
  devtool: "eval-cheap-module-source-map",
  // 开发server
  // npm i webpack-dev-server -D
  devServer: {
    contentBase: path.resolve(__dirname, "dist"),
    port: 9527,
    host: "localhost",
    open: true,
    compress: true,
    hot: true, // 开启HMR功能：提升打包构建速度
  },
  resolve: {
    // 自动补全文件扩展名
    extensions: [".js", ".vue", ".json"],
  },
};
