<template>
  <div id="app">
    <bread-crumb></bread-crumb>
    <router-view></router-view>
  </div>
</template>

<script>
import BreadCrumb from './components/BreadCrumb.vue';

export default {
  components: {
    BreadCrumb,
  },
};
</script>

<style></style>
