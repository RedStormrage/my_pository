/*
  保存n个mutation函数名称的常量模块
*/

export const REQUESTING = 'REQUESTING';
export const REQUEST_SUCCESS = 'REQUEST_SUCCESS';
export const REQUEST_ERROR = 'REQUEST_ERROR';
